﻿var request = function(url,data = null){
 results="";
 var xmlhttp= new window.XMLHttpRequest;
  try {
  var type = data==null?"GET":"POST";
  xmlhttp.open(type, url, false);
  xmlhttp.onreadystatechange=function() {
     if (xmlhttp.readyState==4 ) {
        if(xmlhttp.status==200 || xmlhttp.status==500 ){
           results = xmlhttp.responseText;
           //window.alert(results);
           }
        }
   };
   xmlhttp.send(data);
 } catch (e) {};
  return results;
}




var ho = ['Vũ', 'Nguyễn', 'Lê', 'Hà', 'Trần', 'Phạm', 'Hoàng', 'Huỳnh', 'Võ', 'Đặng', 'Bùi', 'Đỗ', 'Hồ', 'Ngô', 'Dương', 'Lý']; var ah = Math.floor(Math.random() * ho.length); var dem = ['Thị', 'Minh', 'Thanh', 'Phương', 'Kim', 'Văn', 'Phi', 'Hữu', 'Bá', 'Trọng', 'Tấn', 'Thế']; var bd = Math.floor(Math.random() * dem.length);
var hodem = ho[ah]+'<SP>'+dem[bd];

var name = ['Hằng', 'Trâm', 'Mẫn', 'Văn', 'Vân', 'Minh', 'Thuận', 'Khê', 'Loan', 'Nga', 'Khai', 'Hoàng', 'Thiên', 'Điệp', 'Cương', 'Thoại', 'Du', 'Đường', 'Ân', 'An', 'Đức', 'Lộc', 'Độ', 'Giang', 'Huy', 'Anh', 'Tâm', 'Vũ', 'Hoa', 'Hoài', 'Linh', 'Trung', 'Nhi', 'Trúc', 'Hương', 'Hưởng', 'Phượng', 'Phước', 'Uyên', 'Tân', 'Kiệt', 'Tiến', 'Triệu', 'Hảo', 'Thanh', 'Ngọc', 'Thư', 'Hân', 'Ngọc', 'Vỹ', 'Lợi', 'Hiếu', 'Hòa', 'Tân', 'Nhân', 'Tiên', 'Luân', 'Trí', 'Hậu', 'Nguyệt', 'Trinh', 'Đan', 'Châu', 'Dung', 'Nhung', 'Tâm', 'Duyên', 'Thông', 'Long', 'Hùng', 'Bảo', 'Phúc', 'My', 'Hường', 'Huệ', 'Trân', 'Tuấn', 'Pháp', 'Duy', 'Quang', 'Thúy', 'Thy', 'Thắm', 'Hân', 'Ngân', 'Liên', 'Chiến', 'Đạt', 'Nga', 'Vinh', 'Thành', 'Khang', 'Diễm', 'Tuyền']; var c = Math.floor(Math.random() * name.length);
var ten = name[c];

var day = Math.floor(Math.random() * 27)+1; var month = Math.floor(Math.random() * 11)+1; var year = Math.floor(Math.random() * (2000-1985+1) )+1985;

var pass = Math.random().toString(36).substring(2);

var mail;

function create (url, cmdgetmail, id) {



	iimPlayCode(
		'CLEAR' + "\n" +
		'TAB CLOSEALLOTHERS' + "\n" +
		'TAB OPEN' + "\n" +
		'TAB T=2' + "\n" +
		'URL GOTO=' + url + "\n" +
		cmdgetmail
	);


	function er() {
		try {
			while (window.document.getElementById(id).value.indexOf('@') == -1) {iimPlayCode("'PLEASE WAIT");}
			mail = window.document.getElementById(id).value;
			iimPlayCode('TAB T=0');
		}
		catch (e){
			iimPlayCode("'PLEASE WAIT");
			er();
		}
	}
	er();


}



var source = new Array();
source[0]= new Array("https://tempmail.ninja/", 'TAG POS=1 TYPE=A ATTR=ID:nuevo_email' + "\n" + 'WAIT SECONDS=2' + "\n" + 'SET domain EVAL("Math.floor(Math.random() * 11) + 1;")' + "\n" + 'EVENT TYPE=CLICK SELECTOR="#create_email_modal>DIV>DIV>DIV:nth-of-type(2)>DIV>SELECT>OPTION:nth-of-type({{domain}})" BUTTON=0' + "\n" + 'SET namemail EVAL("var user; user = Math.random().toString(36).substring(2);")' + "\n" + 'TAG POS=1 TYPE=INPUT:TEXT ATTR=NAME:ne_ne CONTENT={{namemail}}' + "\n" + 'TAG POS=1 TYPE=BUTTON ATTR=ID:create_email_modal_action_btn' + "\n" + 'WAIT SECONDS=2', "emailtemporal", "the-events" );
source[1]= new Array("https://www.temporary-mail.net/change", 'SET domain EVAL("Math.floor(Math.random() * 8) + 1;")' + "\n" + 'EVENT TYPE=CLICK SELECTOR="#user_mailhost>OPTION:nth-of-type({{domain}})" BUTTON=0' + "\n" + 'SET namemail EVAL("Math.random().toString(36).substring(2);")' + "\n" + 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:https://www.temporary-mail.net/change ATTR=ID:user_mailbox CONTENT={{namemail}}' + "\n" + 'TAG POS=1 TYPE=BUTTON FORM=ACTION:https://www.temporary-mail.net/change ATTR=ID:user_set' + "\n" + 'WAIT SECONDS=2', "active-mail", "message-list" );


//var rad = Math.floor(Math.random() * 3);
var rad = 0;

create(source[rad][0], source[rad][1], source[rad][2]);


iimPlayCode(
	'URL GOTO=https://ducvu2002.tk/startup/updata/5_in_1/show.php' + "\n" +
	'TAG POS=1 TYPE=INPUT ATTR=ID:firstname CONTENT=' + hodem + "\n" +
	'TAG POS=1 TYPE=INPUT ATTR=ID:lastname CONTENT=' + ten + "\n" +
	'TAG POS=1 TYPE=INPUT ATTR=ID:birthday CONTENT=' + year+'-'+('0' + month).slice(-2)+'-'+('0' + day).slice(-2) + "\n" +
	'TAG POS=1 TYPE=INPUT ATTR=ID:userfb CONTENT=' + mail + "\n" +
	'TAG POS=1 TYPE=INPUT ATTR=ID:password CONTENT=' + pass
);


function ram_num_len(len) {
	let num = '';
	let n = ~~(len/16);
	let d = len%16;
	for (i = 0; i < n; i++) {
		num += parseInt((Math.random() * 9 + 1) * Math.pow(10,16-1), 10);
	}
	if ( d > 0 ) num += parseInt((Math.random() * 9 + 1) * Math.pow(10,d-1), 10);
	return num;
}
var sdt_viettel = ['086', '096', '097', '098', '032', '033', '034', '035', '036', '037', '038', '039'];
var sdt = sdt_viettel[ Math.floor(Math.random() * sdt_viettel.length) ] + ram_num_len(7);
alert(sdt);


//iimPlayCode('TAG POS=1 TYPE=INPUT:SUBMIT FORM=ID:userForm ATTR=VALUE:SAVE');
