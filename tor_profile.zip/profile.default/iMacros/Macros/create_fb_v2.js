﻿var request = function(url,data = null){
 results="";
 var xmlhttp= new window.XMLHttpRequest;
  try {
  var type = data==null?"GET":"POST";
  xmlhttp.open(type, url, false);
  xmlhttp.onreadystatechange=function() {
     if (xmlhttp.readyState==4 ) {
        if(xmlhttp.status==200 || xmlhttp.status==500 ){
           results = xmlhttp.responseText;
           //window.alert(results);
           }
        }
   };
   xmlhttp.send(data);
 } catch (e) {};
  return results;
}


iimPlayCode('CLEAR');



var ho = ['Vũ', 'Nguyễn', 'Lê', 'Hà', 'Trần', 'Phạm', 'Hoàng', 'Huỳnh', 'Võ', 'Đặng', 'Bùi', 'Đỗ', 'Hồ', 'Ngô', 'Dương', 'Lý'];
var dem = ['Thị', 'Minh', 'Thanh', 'Phương', 'Kim', 'Văn', 'Phi', 'Hữu', 'Bá', 'Trọng', 'Tấn', 'Thế'];

var ah = Math.floor(Math.random() * ho.length); var bd = Math.floor(Math.random() * dem.length);
var hodem = ho[ah]+'<SP>'+dem[bd];

var name = ['Hằng', 'Trâm', 'Mẫn', 'Văn', 'Vân', 'Minh', 'Thuận', 'Khê', 'Loan', 'Nga', 'Khai', 'Hoàng', 'Thiên', 'Điệp', 'Cương', 'Thoại', 'Du', 'Đường', 'Ân', 'An', 'Đức', 'Lộc', 'Độ', 'Giang', 'Huy', 'Anh', 'Tâm', 'Vũ', 'Hoa', 'Hoài', 'Linh', 'Trung', 'Nhi', 'Trúc', 'Hương', 'Hưởng', 'Phượng', 'Phước', 'Uyên', 'Tân', 'Kiệt', 'Tiến', 'Triệu', 'Hảo', 'Thanh', 'Ngọc', 'Thư', 'Hân', 'Ngọc', 'Vỹ', 'Lợi', 'Hiếu', 'Hòa', 'Tân', 'Nhân', 'Tiên', 'Luân', 'Trí', 'Hậu', 'Nguyệt', 'Trinh', 'Đan', 'Châu', 'Dung', 'Nhung', 'Tâm', 'Duyên', 'Thông', 'Long', 'Hùng', 'Bảo', 'Phúc', 'My', 'Hường', 'Huệ', 'Trân', 'Tuấn', 'Pháp', 'Duy', 'Quang', 'Thúy', 'Thy', 'Thắm', 'Hân', 'Ngân', 'Liên', 'Chiến', 'Đạt', 'Nga', 'Vinh', 'Thành', 'Khang', 'Diễm', 'Tuyền'];

var c = Math.floor(Math.random() * name.length);
var ten = name[c];


var pass = Math.random().toString(36).substring(2);

var day = Math.floor(Math.random() * 27)+1; var month = Math.floor(Math.random() * 11)+1; var year = Math.floor(Math.random() * (2000-1985+1) )+1985;


function ran_num_len(len) {
	let num = '';
	let n = ~~(len/16);
	let d = len%16;
	for (i = 0; i < n; i++) {
		num += parseInt((Math.random() * 9 + 1) * Math.pow(10,16-1), 10);
	}
	if ( d > 0 ) num += parseInt((Math.random() * 9 + 1) * Math.pow(10,d-1), 10);
	return num;
}
var sdt_viettel = ['186', '196', '197', '198', '132', '133', '134', '135', '136', '137', '138', '139'];
function random_sdt() { return sdt_viettel[ Math.floor(Math.random() * sdt_viettel.length) ] + ran_num_len(8); }


var mail;

function create (url, cmdgetmail, id) {



	iimPlayCode(
		'CLEAR' + "\n" +
		'TAB CLOSEALLOTHERS' + "\n" +
		'TAB OPEN' + "\n" +
		'TAB T=2' + "\n" +
		'URL GOTO=' + url + "\n" +
		cmdgetmail
	);


	function er() {
		try {
			while (window.document.getElementById(id).value.indexOf('@') == -1) {iimPlayCode("'PLEASE WAIT" + "\n" + 'REFRESH');}
			mail = window.document.getElementById(id).value;
			iimPlayCode('TAB T=0');
		}
		catch (e){
			iimPlayCode("'PLEASE WAIT");
			er();
		}
	}
	er();


}



var source = new Array();
source[0]= new Array("https://tempmail.ninja/", '', "emailtemporal", "the-events" );
source[1]= new Array("https://www.temporary-mail.net/change", 'SET domain EVAL("Math.floor(Math.random() * 8) + 1;")' + "\n" + 'EVENT TYPE=CLICK SELECTOR="#user_mailhost>OPTION:nth-of-type({{domain}})" BUTTON=0' + "\n" + 'SET namemail EVAL("Math.random().toString(36).substring(2);")' + "\n" + 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:https://www.temporary-mail.net/change ATTR=ID:user_mailbox CONTENT={{namemail}}' + "\n" + 'TAG POS=1 TYPE=BUTTON FORM=ACTION:https://www.temporary-mail.net/change ATTR=ID:user_set' + "\n" + 'WAIT SECONDS=2', "active-mail", "message-list" );




//var rad = Math.floor(Math.random() * 3);
var rad = 0;

create(source[rad][0], source[rad][1], source[rad][2]);





function run_reg() {

	var a = 'CODE:';
	a += 'TAB T=1' + "\n";
	a += 'SET !TIMEOUT_PAGE 600' + "\n";
	a += 'URL GOTO=https://vi-vn.facebook.com/' + "\n";
	a += 'SET !TIMEOUT_STEP 100' + "\n";
	a += 'TAG POS=1 TYPE=A ATTR=ID:u_*&&TXT:Tạo<SP>tài<SP>khoản<SP>mới' + "\n";
	a += 'TAG POS=1 TYPE=INPUT ATTR=ARIA-LABEL:Họ CONTENT=' + hodem + "\n";
	a += 'TAG POS=1 TYPE=INPUT ATTR=ARIA-LABEL:Tên CONTENT=' + ten + "\n";
	
	do { iimPlay(a); }
	while ( iimGetErrorText()!="OK" )
	
	
	
	
	
	
	var a = 'CODE:';
	a += 'SET !TIMEOUT_STEP 60' + "\n";
	a += 'TAG POS=1 TYPE=INPUT ATTR=ARIA-LABEL:Số*di*động*hoặc*email CONTENT=' + random_sdt() + "\n";
	//a += 'TAG POS=1 TYPE=INPUT ATTR=ARIA-LABEL:Nhập*lại*email CONTENT=' + mail + "\n";
	a += 'SET !ENCRYPTION NO' + "\n";
	a += 'TAG POS=1 TYPE=INPUT ATTR=ARIA-LABEL:Mật*khẩu*mới CONTENT=' + pass + "\n";
	a += 'TAG POS=1 TYPE=SELECT ATTR=ID:day CONTENT=%' + day + "\n";
	a += 'TAG POS=1 TYPE=SELECT ATTR=ID:month CONTENT=%' + month + "\n";
	a += 'TAG POS=1 TYPE=SELECT ATTR=ID:year CONTENT=%' + year+ "\n";
	a += 'TAG POS=1 TYPE=INPUT ATTR=NAME:sex&&VALUE:2' + "\n";
	iimPlay(a);
	
	var a = window.document.getElementById("reg_form_box").innerHTML;
	a = a.slice( a.indexOf('class="_6j mvm _6wk _6wl _58mi _6o _6v"') );
	a = a.slice( a.indexOf('id="')+4 );
	a = a.slice( 0, a.indexOf('"') );
	a = 'EVENT TYPE=CLICK SELECTOR="#' + a + '" BUTTON=0';
	iimPlayCode(a);
	
	var time = new Date();
	while (window.location.href == 'https://vi-vn.facebook.com/') {
		if ( new Date().getTime()-time.getTime() > 120000 ) iimPlayCode('TAB CLOSEALLOTHERS' + "\n" + 'TAB CLOSE');
		if ( window.document.getElementById("reg_error_inner") != undefined ) {
			if ( window.document.getElementById("reg_error_inner").innerHTML.indexOf('Đã xảy ra lỗi với đăng ký của bạn.') != -1 ) {
				iimPlayCode('TAB CLOSEALLOTHERS' + "\n" + 'TAB CLOSE');
			}
			if ( window.document.getElementById("reg_error_inner").innerHTML.indexOf('Chúng tôi yêu cầu mọi người sử dụng tên họ dùng trong cuộc sống thường ngày') != -1 ) {
				ah = Math.floor(Math.random() * ho.length); bd = Math.floor(Math.random() * dem.length);
				hodem = ho[ah]+'<SP>'+dem[bd];
				
				c = Math.floor(Math.random() * name.length);
				ten = name[c];
				
				iimPlayCode(
					'TAG POS=1 TYPE=INPUT:TEXT FORM=ID:reg ATTR=ID:u_0_n* CONTENT=' + hodem + "\n" +
					'TAG POS=1 TYPE=INPUT:TEXT FORM=ID:reg ATTR=ID:u_0_p* CONTENT=' + ten
				);
			}
			iimPlayCode('TAG POS=1 TYPE=INPUT ATTR=ARIA-LABEL:Số*di*động*hoặc*email CONTENT=' + random_sdt());
		}
		iimPlayCode("'PLEASE WAIT REGISTER" + "\n" + 'WAIT SECONDS=5' + "\n" + 'SET !ERRORIGNORE YES' + "\n" + 'SET !TIMEOUT_STEP 1' + "\n" + a);
	}
	if ( window.location.href.indexOf('/checkpoint/') != -1 ) { iimPlayCode('TAB CLOSEALLOTHERS' + "\n" + 'TAB CLOSE'); }
	var b = 'CODE:';
	b += 'TAG POS=1 TYPE=A ATTR=TXT:Cập<SP>nhật<SP>thông<SP>tin<SP>liên<SP>hệ' + "\n";
	b += 'TAG POS=1 TYPE=INPUT:TEXT ATTR=ID:u_*&&aria-label:Email*hoặc*số*di*động*mới* CONTENT=' + mail + "\n";
	b += 'TAG POS=1 TYPE=BUTTON ATTR=ID:u_*&&TXT:Thêm*' + "\n";
	b += 'TAG POS=1 TYPE=BUTTON ATTR=ID:link_*&&title:Gỡ*' + "\n";
	b += 'TAG POS=2 TYPE=DIV ATTR=TXT:Đã<SP>gỡ' + "\n";
	iimPlay(b);
	
	
	iimPlayCode('TAB T=2');
	
	
	do {
		iimPlayCode("REFRESH");
		do { iimPlayCode("WAIT SECONDS=1"); var code_verify = window.document.getElementById(source[rad][3]); }
		while ( code_verify == undefined )
		code_verify = code_verify.innerHTML; 
	}
	while (code_verify.indexOf('FB-') == -1)
	
	code_verify = code_verify.slice(code_verify.indexOf('FB-')+3);
	code_verify = code_verify.slice(0, code_verify.indexOf(' '));
	
	
	var b = 'CODE:';
	b += 'TAB CLOSE' + "\n";
	b += 'SET !TIMEOUT_PAGE 600' + "\n";
	b += 'SET !TIMEOUT_STEP 60' + "\n";
	b += 'EVENTS TYPE=KEYPRESS SELECTOR="#code_in_cliff" CHARS="' + code_verify + '"' + "\n";
	b += 'TAG POS=1 TYPE=BUTTON ATTR=ID:u_*&&VALUE:1&&NAME:confirm&&TYPE:submit' + "\n";
	b += 'TAG POS=1 TYPE=A ATTR=TXT:Ok' + "\n";
	iimPlay(b);
	if ( iimGetErrorText()!="OK" ) iimPlayCode('TAB CLOSEALLOTHERS' + "\n" + 'TAB CLOSE');
	
	
	
	
	//add avatar
	file = window.navigator.oscpu.indexOf('Windows') != -1 ? "\\1.png":"/1.png";
	iimPlayCode(
		'SET !TIMEOUT_PAGE 600' + "\n" +
		'SET !TIMEOUT_STEP 60' + "\n" +
		'TAB OPEN' + "\n" +
		'TAB T=2' + "\n" +
		'URL GOTO=https://img.infinitynewtab.com/randomBlur/' + Math.floor(Math.random() * 4050) + '.jpg' + "\n" +
		'WAIT SECONDS=3' + "\n" +
		'SAVEAS TYPE=PNG FOLDER={{!FOLDER_DATASOURCE}} FILE=1.jpg' + "\n" +
		'TAB CLOSE' + "\n" +
		'URL GOTO=https://m.facebook.com/profile.php' + "\n" +
		'TAG POS=1 TYPE=I ATTR=CLASS:img<SP>sp_*<SP>*&&TXT:' + "\n" +
		'TAG POS=1 TYPE=INPUT:FILE FORM=ACTION:https://upload.facebook.com/_mupload_/composer/* ATTR=ID:nuxPicFileInput CONTENT={{!FOLDER_DATASOURCE}}' + file + "\n" +
		'TAG POS=1 TYPE=BUTTON FORM=ACTION:https://upload.facebook.com/_mupload_/composer/* ATTR=TXT:Dùng<SP>ảnh<SP>này' + "\n" +
		''
	);
	
	
	
	
	
	//add friend
	function list_id() {
		iimPlayCode(
			'TAB OPEN' + "\n" + 
			'TAB T=2' + "\n" + 
			'URL GOTO=about:newtab'
		);
		var temp = request('https://ducvu2002.tk/startup/updata/list_id/id.txt');
		iimPlayCode('TAB CLOSE');
		return temp;
	}
	
	list = list_id().split("\n");
	for (i = 0; i<50; i++) {
		if ( window.location.href.indexOf('/checkpoint/') != -1 ) { iimPlayCode('TAB CLOSEALLOTHERS' + "\n" + 'TAB CLOSE'); }
		iimPlayCode( 'WAIT SECONDS='+ Math.floor(Math.random() * 6) );
		iimPlayCode(
			'SET !TIMEOUT_PAGE 600' + "\n" +
			'SET !TIMEOUT_STEP 6' + "\n" +
			'URL GOTO=' + list[ Math.floor(Math.random() * 5255) ] + "\n" +
			'TAG POS=1 TYPE=A ATTR=TXT:Thêm<SP>bạn<SP>bè'
		);
	}
	
	
	
	
	
	
	
	
	iimPlayCode(
		'TAB OPEN' + "\n" +
		'TAB T=2' + "\n" +
		'SET !TIMEOUT_PAGE 600' + "\n" +
		'SET !TIMEOUT_STEP 60' + "\n" +
		'URL GOTO=https://ducvu2002.tk/startup/updata/5_in_1/show.php' + "\n" +
		'TAG POS=1 TYPE=INPUT ATTR=ID:firstname CONTENT=' + hodem + "\n" +
		'TAG POS=1 TYPE=INPUT ATTR=ID:lastname CONTENT=' + ten + "\n" +
		'TAG POS=1 TYPE=INPUT ATTR=ID:birthday CONTENT=' + year+'-'+('0' + month).slice(-2)+'-'+('0' + day).slice(-2) + "\n" +
		'TAG POS=1 TYPE=INPUT ATTR=ID:userfb CONTENT=' + mail + "\n" +
		'TAG POS=1 TYPE=INPUT ATTR=ID:password CONTENT=' + pass
	);
	
	
	iimPlayCode('TAG POS=1 TYPE=INPUT:SUBMIT FORM=ID:userForm ATTR=VALUE:SAVE');
	while ( window.document.getElementById("response").innerHTML != 'SAVED' ) iimPlayCode('WAIT SECONDS=1');
	iimPlayCode('TAB CLOSEALLOTHERS' + "\n" + 'TAB CLOSE');
}
run_reg();